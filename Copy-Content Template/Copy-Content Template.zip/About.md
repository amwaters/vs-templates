﻿# Copy-Content Template

This project will simply copy all files in the project with Build Action = Content to the output directory when building.

There will be no compiling.

Based on the [excellent article by Eilon Lipton](http://weblogs.asp.net/leftslipper/creating-visual-studio-projects-that-only-contain-static-files)
