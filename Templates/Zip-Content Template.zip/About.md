﻿# Zip-Content Template

This project will simply add all files in the project with Build Action = Content to a zip in the output directory when building.

There will be no compiling.
